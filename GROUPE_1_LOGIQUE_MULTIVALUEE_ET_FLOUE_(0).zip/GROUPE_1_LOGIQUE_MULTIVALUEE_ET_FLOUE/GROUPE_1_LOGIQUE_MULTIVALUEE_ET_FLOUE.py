import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import matplotlib.pyplot as plt


# 1. Définir les variables floues
satisfaction = ctrl.Antecedent(np.arange(0, 11, 1), 'satisfaction')  # Échelle de 0 à 10
prix = ctrl.Antecedent(np.arange(0, 101, 1), 'prix')  # Échelle de 0 à 100
recommandation = ctrl.Consequent(np.arange(0, 101, 1), 'recommandation')  # Échelle de 0 à 100

# 2. Définir les ensembles flous pour satisfaction
satisfaction['faible'] = fuzz.trapmf(satisfaction.universe, [0, 0, 2, 5])  # Faible satisfaction
satisfaction['moyenne'] = fuzz.trimf(satisfaction.universe, [3, 5, 7])  # Moyenne satisfaction
satisfaction['élevée'] = fuzz.trapmf(satisfaction.universe, [5, 8, 10, 10])  # Haute satisfaction

# 3. Définir les ensembles flous pour prix
prix['bas'] = fuzz.trapmf(prix.universe, [0, 0, 25, 50])  # Prix bas
prix['moyen'] = fuzz.trimf(prix.universe, [25, 50, 75])  # Prix moyen
prix['élevé'] = fuzz.trapmf(prix.universe, [50, 75, 100, 100])  # Prix élevé

# 4. Définir les ensembles flous pour recommandation
recommandation['faible'] = fuzz.trapmf(recommandation.universe, [0, 0, 25, 50])  # Faible recommandation
recommandation['moyenne'] = fuzz.trimf(recommandation.universe, [25, 50, 75])  # Moyenne recommandation
recommandation['forte'] = fuzz.trapmf(recommandation.universe, [50, 75, 100, 100])  # Forte recommandation

# 5. Définir les règles floues
rule1 = ctrl.Rule(prix['bas'] & satisfaction['élevée'], recommandation['forte'])
rule2 = ctrl.Rule(prix['moyen'] & satisfaction['moyenne'], recommandation['moyenne'])
rule3 = ctrl.Rule(prix['élevé'] | satisfaction['faible'], recommandation['faible'])

# 6. Créer le système de contrôle flou
recommandation_ctrl = ctrl.ControlSystem([rule1, rule2, rule3])
recommande = ctrl.ControlSystemSimulation(recommandation_ctrl)

# 7. Entrer les données utilisateur (exemple)
recommande.input['satisfaction'] = 8  # Satisfaction sur 10
recommande.input['prix'] = 40  # Prix sur 100

# 8. Calculer la recommandation
recommande.compute()

# 9. Afficher les résultats
print(f"Recommandation : {recommande.output['recommandation']:.2f}%")

# 10. Visualiser les résultats
satisfaction.view()  # Visualisation des ensembles flous pour satisfaction
prix.view()  # Visualisation des ensembles flous pour prix
recommandation.view(sim=recommande)  # Visualisation des résultats pour recommandation
plt.show()
